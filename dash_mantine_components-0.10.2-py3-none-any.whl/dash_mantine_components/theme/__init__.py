from dash_mantine_components.theme.default_colors import DEFAULT_COLORS

__all__ = ["DEFAULT_COLORS"]
