from xiplot.utils.cli import cli

cli()
