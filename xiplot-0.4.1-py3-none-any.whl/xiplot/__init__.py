from xiplot.utils.cli import cli  # noqa: F401
